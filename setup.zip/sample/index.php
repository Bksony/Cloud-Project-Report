<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.php');  // Redirect to login page if not logged in
    exit();
}

// Include database configuration
include('config.php');

// Fetch user information from the database
$email = $_SESSION['email'];
$query = "SELECT * FROM user WHERE email = '$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a CSS file -->
</head>
<body>
    <div class="navbar">
        <h2>Welcome to Your Profile</h2>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="profile">
            <h3>User Profile</h3>
            <p><strong>Name:</strong> <?php echo $user['name']; ?></p>
            <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
            <p><strong>Mobile:</strong> <?php echo $user['mobile']; ?></p>
            <p><strong>Address:</strong> <?php echo $user['address']; ?></p>
            <p><strong>Pincode:</strong> <?php echo $user['pincode']; ?></p>
        </div>
    </div>
</body>
</html>
