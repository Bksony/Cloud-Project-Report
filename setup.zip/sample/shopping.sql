-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2025 at 08:38 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` varchar(45) NOT NULL,
  `prodid` varchar(45) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `shipped` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `prodid`, `quantity`, `amount`, `shipped`) VALUES
('O001', 'P001', 2, '1399.98', 0),
('O002', 'P003', 1, '199.99', 1),
('O003', 'P007', 5, '99.95', 0),
('O004', 'P005', 1, '499.99', 1),
('O005', 'P010', 3, '299.97', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` varchar(45) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `ptype` varchar(20) DEFAULT NULL,
  `pinfo` varchar(350) DEFAULT NULL,
  `pprice` decimal(12,2) UNSIGNED NOT NULL,
  `pquantity` int(11) UNSIGNED NOT NULL,
  `image` longblob DEFAULT NULL,
  `vendorid` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `ptype`, `pinfo`, `pprice`, `pquantity`, `image`, `vendorid`) VALUES
('P001', 'Smartphone', 'Electronics', 'Latest smartphone with 6GB RAM', '699.99', 50, NULL, 'V001'),
('P002', 'Laptop', 'Electronics', 'Lightweight laptop with 512GB SSD', '999.99', 30, NULL, 'V001'),
('P003', 'Headphones', 'Accessories', 'Wireless headphones with noise cancellation', '199.99', 100, NULL, 'V002'),
('P004', 'Microwave', 'Appliances', 'Compact microwave oven', '249.99', 20, NULL, 'V003'),
('P005', 'Sofa Set', 'Furniture', '3-seater luxury sofa', '499.99', 10, NULL, 'V003'),
('P006', 'Jeans', 'Clothing', 'Slim-fit denim jeans', '49.99', 200, NULL, 'V004'),
('P007', 'T-Shirt', 'Clothing', 'Comfortable cotton T-shirt', '19.99', 300, NULL, 'V004'),
('P008', 'Fitness Band', 'Electronics', 'Water-resistant fitness band', '149.99', 80, NULL, 'V002'),
('P009', 'Washing Machine', 'Appliances', 'Front-loading washing machine', '799.99', 15, NULL, 'V003'),
('P010', 'Blender', 'Appliances', 'High-speed blender for smoothies', '99.99', 25, NULL, 'V003');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transid` varchar(45) NOT NULL,
  `username` varchar(60) DEFAULT NULL,
  `time` datetime DEFAULT current_timestamp(),
  `amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(100) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` char(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `name`, `mobile`, `address`, `pincode`, `password`) VALUES
('user1@example.com', 'JohnDoe', '1234567890', '123MainSt', '123456', '$2y$10$tAQXp2pnFITzXfekuyFbTugeGlGYJW49hsWSUT5lrSn2/YeonGAJG'),
('user2@example.com', 'Bob', '9876543215', '456 Oak Avenue, NY', '234567', 'bob456'),
('user3@example.com', 'Charlie', '9876543216', '789 Pine Road, TX', '345678', 'charlie789'),
('user4@example.com', 'Diana', '9876543217', '321 Cedar Lane, LA', '456789', 'diana321');

-- --------------------------------------------------------

--
-- Table structure for table `usercart`
--

CREATE TABLE `usercart` (
  `username` varchar(60) DEFAULT NULL,
  `prodid` varchar(45) DEFAULT NULL,
  `quantity` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_demand`
--

CREATE TABLE `user_demand` (
  `username` varchar(60) NOT NULL,
  `prodid` varchar(45) NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `vendorid` varchar(45) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` char(10) NOT NULL,
  `address` varchar(250) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`vendorid`, `name`, `email`, `mobile`, `address`, `password`) VALUES
('V001', 'Tech World', 'techworld@example.com', '9876543210', '123 Silicon Valley, CA', 'tech123'),
('V002', 'Gadget Hub', 'gadgethub@example.com', '9876543211', '456 Tech Park, NY', 'gadget456'),
('V003', 'Home Essentials', 'homeessentials@example.com', '9876543212', '789 Urban Street, TX', 'home789'),
('V004', 'Fashion Fiesta', 'fashionfiesta@example.com', '9876543213', '321 Fashion Lane, LA', 'fashion321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`,`prodid`),
  ADD KEY `productid_idx` (`prodid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `vendorid_idx` (`vendorid`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transid`),
  ADD KEY `truserid_idx` (`username`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `unique_mobile` (`mobile`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indexes for table `usercart`
--
ALTER TABLE `usercart`
  ADD KEY `useremail_idx` (`username`),
  ADD KEY `prodidcart_idx` (`prodid`);

--
-- Indexes for table `user_demand`
--
ALTER TABLE `user_demand`
  ADD PRIMARY KEY (`username`,`prodid`),
  ADD KEY `prodid_idx` (`prodid`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`vendorid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unique_vendor_mobile` (`mobile`),
  ADD UNIQUE KEY `unique_vendor_email` (`email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `productid` FOREIGN KEY (`prodid`) REFERENCES `product` (`pid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_vendor` FOREIGN KEY (`vendorid`) REFERENCES `vendor` (`vendorid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_transaction_user` FOREIGN KEY (`username`) REFERENCES `user` (`email`) ON DELETE CASCADE,
  ADD CONSTRAINT `transorderid` FOREIGN KEY (`transid`) REFERENCES `orders` (`orderid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `usercart`
--
ALTER TABLE `usercart`
  ADD CONSTRAINT `fk_usercart_user` FOREIGN KEY (`username`) REFERENCES `user` (`email`) ON DELETE CASCADE,
  ADD CONSTRAINT `prodidcart` FOREIGN KEY (`prodid`) REFERENCES `product` (`pid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user_demand`
--
ALTER TABLE `user_demand`
  ADD CONSTRAINT `fk_userdemand_user` FOREIGN KEY (`username`) REFERENCES `user` (`email`) ON DELETE CASCADE,
  ADD CONSTRAINT `prodid` FOREIGN KEY (`prodid`) REFERENCES `product` (`pid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `userdemailemail` FOREIGN KEY (`username`) REFERENCES `user` (`email`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
