<?php

    // Enable error reporting for mysqli
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    // Database credentials
    $servername = "localhost";
    $username = "username";
    $password = "password";
    $dbname = "shopping";

    try {
        // Create a new database connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        $conn->set_charset("utf8mb4"); // Set character set
    } catch (mysqli_sql_exception $e) {
        // Handle connection errors
        error_log("Database connection error: " . $e->getMessage());
        die("A database error occurred. Please try again later.");
    }
?>
